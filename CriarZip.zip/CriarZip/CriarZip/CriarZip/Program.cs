﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CriarZip
{
    class Program
    {
        static void Main(string[] args)
        {
            GerarZip();
        }


        #region Variáveis

        // Diretório temporario
        public static readonly string DiretorioBase = Path.GetTempPath();

        // Diretório para geração do arquivo de estrutura txt
        public static readonly string Diretorio = DiretorioBase + "\\Estrutura.txt";

        // Diretório de estrutura de pastas 
        public static readonly string DiretorioPasta = DiretorioBase + "\\EstruturaPasta\\";

        // Diretório de criação de arquivo Zip
        public static readonly string DiretorioPastaZip = DiretorioBase + "\\EstruturaPasta.zip";

        #endregion

        public static void GerarZip()
        {
            // Ler retorno de bytes, criar arquivo txt e escrever diretório de pastas
            System.IO.File.WriteAllBytes(Diretorio, RetornArrayBytes());

            // Criando diretório fisico de pastas conforme Bytes
            CriarDiretorios();

            // Criando Zip de pastas com base no arquivo txt
            CriarArquivoZip();

            // Converte arquivo para Byte para retorno caso precisar
            byte[] data = File.ReadAllBytes(DiretorioPastaZip);

        }


        /// <summary>
        /// Ler Arquivo txt e criar estrutura de pastas
        /// </summary>
        public static void CriarDiretorios()
        {
            string line;

            if (Directory.Exists(DiretorioPasta))
                Directory.Delete(DiretorioPasta, true);

            System.IO.StreamReader file =
            new System.IO.StreamReader(Diretorio);
            while ((line = file.ReadLine()) != null)
            {
                if (!Directory.Exists(DiretorioPasta + line))
                    Directory.CreateDirectory(DiretorioPasta + line);

            }
        }

        /// <summary>
        /// Cria arquivo Zip
        /// </summary>
        public static void CriarArquivoZip()
        {
            if (File.Exists(DiretorioPastaZip))
            {
                File.Delete(DiretorioPastaZip);
            }

            ZipFile.CreateFromDirectory(DiretorioPasta, DiretorioPastaZip);
        }

        /// <summary>
        /// Transforma arquivo Zip em Bytes
        /// </summary>
        /// <param name="filename"></param>
        /// <returns></returns>
        public byte[] StreamFile(string filename)
        {
            FileStream fs = new FileStream(filename, FileMode.Open, FileAccess.Read);

            // Create a byte array of file stream length
            byte[] ImageData = new byte[fs.Length];

            //Read block of bytes from stream into the byte array
            fs.Read(ImageData, 0, System.Convert.ToInt32(fs.Length));

            //Close the File Stream
            fs.Close();
            return ImageData; //return the byte data
        }

        /// <summary>
        /// Simulando retorno de Bytes enviados pelo cliente
        /// </summary>
        /// <returns></returns> 
        public static byte[] RetornArrayBytes()
        {

            string Valor = "/root" + Environment.NewLine +
                                "/root/cfg" + Environment.NewLine +
                                "/root/index" + Environment.NewLine +
                                "/root/lua" + Environment.NewLine +
                                "/root/lua/financgui" + Environment.NewLine +
                                "/root/lua/financrn" + Environment.NewLine +
                                "/root/lua/hello";

            byte[] binaryData;

            using (MemoryStream memStream = new MemoryStream(Encoding.ASCII.GetBytes(Valor)))
            {
                binaryData = memStream.ToArray();
            }

            return binaryData;
        }

    }
}
